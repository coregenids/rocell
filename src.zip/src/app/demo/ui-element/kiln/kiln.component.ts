import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-kiln',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './kiln.component.html',
  styleUrl: './kiln.component.scss'
})
export default class KilnComponent {

}
