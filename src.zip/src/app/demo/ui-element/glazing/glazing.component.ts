import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-glazing',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './glazing.component.html',
  styleUrl: './glazing.component.scss'
})
export default class GlazingComponent {

}
